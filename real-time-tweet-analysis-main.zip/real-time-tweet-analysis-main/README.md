# real-time-tweet-analysis
- look in the presentation contains all the details of this project (Big-Data.pptx and UASB03_Projet_Feraudet_v1.0.pdf)
